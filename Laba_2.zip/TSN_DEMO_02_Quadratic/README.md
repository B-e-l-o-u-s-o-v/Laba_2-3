# TSN_DEMO_02_Quadratic
Квадратное уравнение (с 2-мя разметками)
![Screenshot](screenshot.png)

